<?php

namespace App\Http\Livewire;

use Livewire\Component;

class SiderBarApp extends Component
{
    public function render()
    {
        return view('livewire.sider-bar-app');
    }
}
