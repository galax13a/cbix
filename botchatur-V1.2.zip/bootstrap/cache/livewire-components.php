<?php return array (
  'apichaturs' => 'App\\Http\\Livewire\\Apichaturs',
  'com-dark-wire' => 'App\\Http\\Livewire\\ComDarkWire',
  'com-select-table-wire' => 'App\\Http\\Livewire\\ComSelectTableWire',
  'language-switcher' => 'App\\Http\\Livewire\\LanguageSwitcher',
  'pages' => 'App\\Http\\Livewire\\Pages',
  'scrape-component' => 'App\\Http\\Livewire\\ScrapeComponent',
  'sidebar-wire' => 'App\\Http\\Livewire\\SidebarWire',
  'sider-bar-app' => 'App\\Http\\Livewire\\SiderBarApp',
);