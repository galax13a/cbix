<div>
    <!-- Card Home APP -->
    <section class="section">
        <div class="container">           
                    <x-com-card-page/>     
        </div>
    </section>
</div>