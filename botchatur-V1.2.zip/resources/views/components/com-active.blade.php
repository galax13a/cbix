<div>
  {{ $active ? '🟢' : '🔴' }} 
</div>