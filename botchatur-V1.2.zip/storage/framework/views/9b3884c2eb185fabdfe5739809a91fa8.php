<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pages')->html();
} elseif ($_instance->childHasBeenRendered('zeOoEmd')) {
    $componentId = $_instance->getRenderedChildComponentId('zeOoEmd');
    $componentTag = $_instance->getRenderedChildComponentTagName('zeOoEmd');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('zeOoEmd');
} else {
    $response = \Livewire\Livewire::mount('pages');
    $html = $response->html();
    $_instance->logRenderedChild('zeOoEmd', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>     
    </div>   
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\BASE\Botchatur\Admin\resources\views/livewire/pages/index.blade.php ENDPATH**/ ?>