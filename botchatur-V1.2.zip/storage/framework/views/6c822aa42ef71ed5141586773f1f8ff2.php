<?php $__env->startSection('title', __('Dashboard')); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row justify-content-center">
	<div class="col-md-12 py-1">
		<div class="card border-0">
			<div class="card-header1 mx-2 my-2"><h3><span class="text-center fa fa-home"></span> <?php echo $__env->yieldContent('title'); ?></h3></div>
			<div class="card-body">
			     							
				 <div class="row w-100 h-100">
					<?php if(auth()->guest()): ?>
					<h1>Home</h1>
					<?php else: ?>
						<?php if (isset($component)) { $__componentOriginala9d219952e0b8975c33eb6712ccee830 = $component; } ?>
<?php $component = App\View\Components\ComCardHome::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ComCardHome'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ComCardHome::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala9d219952e0b8975c33eb6712ccee830)): ?>
<?php $component = $__componentOriginala9d219952e0b8975c33eb6712ccee830; ?>
<?php unset($__componentOriginala9d219952e0b8975c33eb6712ccee830); ?>
<?php endif; ?> 
					<?php endif; ?>
				</div>
				
	</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\BASE\Botchatur\Admin\resources\views/home.blade.php ENDPATH**/ ?>