<div>
    <select wire:model="<?php echo e(rtrim($tableName, 's') . '_id'); ?>" id="<?php echo e(rtrim($tableName, 's') . '_id'); ?>">
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>"><?php echo e($item->{$displayName}); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    
</div>
<?php /**PATH C:\Users\USER\Desktop\BASE\Botchatur\Admin\resources\views/livewire/com-select-table-wire.blade.php ENDPATH**/ ?>