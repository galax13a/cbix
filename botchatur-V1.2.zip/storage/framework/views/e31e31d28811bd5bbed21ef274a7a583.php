<div>
    <!-- Card Home APP -->
    <section class="section">
        <div class="container">           
                    <?php if (isset($component)) { $__componentOriginalcaf12846d89f210984cdf525151ed22f = $component; } ?>
<?php $component = App\View\Components\ComCardPage::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('com-card-page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ComCardPage::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcaf12846d89f210984cdf525151ed22f)): ?>
<?php $component = $__componentOriginalcaf12846d89f210984cdf525151ed22f; ?>
<?php unset($__componentOriginalcaf12846d89f210984cdf525151ed22f); ?>
<?php endif; ?>     
        </div>
    </section>
</div><?php /**PATH C:\Users\USER\Desktop\BASE\Botchatur\Admin\resources\views/components/com-card-home.blade.php ENDPATH**/ ?>