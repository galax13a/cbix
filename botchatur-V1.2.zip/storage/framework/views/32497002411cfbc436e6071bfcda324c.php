<div>
    <div class="btn-group" role="group" aria-label="Basic example">
        <p  class="punter m-1" data-bs-toggle="modal" data-bs-target="#updateDataModal" class="dropdown-item" wire:click="edit(<?php echo e($id_editar); ?>)">
            ✅
        </p>        
        <p   class="punter m-1" onclick="confirm('Confirm Delete Row ? \nDeleted Row cannot be recovered!')||event.stopImmediatePropagation()" wire:click="destroy(<?php echo e($id_editar); ?>)" >
            ❌
        </p>
      </div>
</div>
<?php /**PATH C:\Users\USER\Desktop\BASE\Botchatur\Admin\resources\views/components/btncrud.blade.php ENDPATH**/ ?>