<div>
    
    <div>
        <input wire:model="url" type="text" placeholder="Enter URL here">
        <button wire:click="scrape">Scrape!</button>
        <?php if($statusMessage): ?>
            <div class="alert">
                <?php echo e($statusMessage); ?>

            </div>
        <?php endif; ?>
        <p><?php echo e($data); ?></p>
    </div>
    
    
    
</div>
<?php /**PATH C:\Users\USER\Desktop\BASE\Botchatur\Admin\resources\views/livewire/scrape-component.blade.php ENDPATH**/ ?>