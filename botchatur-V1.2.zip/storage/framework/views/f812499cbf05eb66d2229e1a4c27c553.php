<div>   
    <div class="row">
       
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-lg-4 m-4px-tb punter">
                    <div class="media rounded-4 p-2 my-2 box-shadow-only-hover hover-top border-all-1 border-color-gray p-6px">
                        <div class="icon-50 <?php echo e($item['color']); ?> white-color border-radius-50 d-inline-block">
                            <i class="number"><?php echo e($item['icon']); ?></i>
                        </div>
                        <div class="p-20px-l media-body">
                            <span class="theme2nd-bg white-color p-0px-tb p-10px-lr font-small border-radius-15"><?php echo e($item['onlineModels']); ?></span>
                            <h5 class="m-5px-tb"><?php echo e($item['siteName']); ?></h5>
                            <p class="m-0px font-small">
                                <?php $__currentLoopData = $item['links']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e($link['url']); ?>"><?php echo e($link['label']); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
        
        </div>
      
</div><?php /**PATH C:\Users\USER\Desktop\BASE\Botchatur\Admin\resources\views/components/com-card-page.blade.php ENDPATH**/ ?>