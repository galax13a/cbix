<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('apichaturs')->html();
} elseif ($_instance->childHasBeenRendered('I2WlIiw')) {
    $componentId = $_instance->getRenderedChildComponentId('I2WlIiw');
    $componentTag = $_instance->getRenderedChildComponentTagName('I2WlIiw');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('I2WlIiw');
} else {
    $response = \Livewire\Livewire::mount('apichaturs');
    $html = $response->html();
    $_instance->logRenderedChild('I2WlIiw', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>     
    </div>   
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\BASE\Botchatur\Admin\resources\views/livewire/apichaturs/index.blade.php ENDPATH**/ ?>