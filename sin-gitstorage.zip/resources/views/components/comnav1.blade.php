<div>
    <!-- It is never too late to be what you might have been. - George Eliot -->
    <!-- As a heading -->
    <nav class="navbar">
        <div class="container-fluid">
            <a href="#memberplus" class="navbar-brand mb-0 h1">🏅 Member Plus</a>
            <a href="#appbot" class="navbar-brand mb-0 h2">🐞 app bot</a>
            <a href="#appchat" class="navbar-brand mb-0 h3">🗨️ app chat</a>
            <a href="#videochat" class="navbar-brand mb-0 h3">👅 video chat</a>
            <a href="#videos" class="navbar-brand mb-0 h3">🫦 videos </a>
            <!--  dark mode -->
            <a href="#videos" class="navbar-brand mb-0 h3"> <livewire:com-dark-wire /> </a>                       
            <!-- ... -->
        </div>

</div>
</nav>

</div>
