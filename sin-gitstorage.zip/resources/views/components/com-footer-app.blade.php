<div>
    <!-- The footer -->
<!-- resources/views/components/com-footer-app.blade.php -->
<footer class="footer mt-auto py-3">
    <div class="container d-flex justify-content-center align-items-center">
        <span class="text-muted">© 2015 botchatur.com. All rights reserved.</span>
        <div class="footer-links mt-2 p-2">
            <a href="mailto:contact@botchatur.com" class="text-muted me-3">Contact</a>
            <a href="/help" class="text-muted">Help</a> /
            <a href="/help" class="text-muted">Apps</a>
        </div>
    </div>
</footer>

    
</div>