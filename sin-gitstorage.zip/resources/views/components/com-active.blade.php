<div>
    {{ $active ? '🟢' : '🔴' }}
</div>