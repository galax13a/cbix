<div>
    <?php echo e($active ? '🟢' : '🔴'); ?>

</div><?php /**PATH C:\Users\USER\Desktop\BASE\Botchatur\Admin\resources\views/components/com-active.blade.php ENDPATH**/ ?>