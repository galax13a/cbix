<?php $__env->startSection('title', __('Pages')); ?>
<div class="container-fluid">
	<div class="row justify-content-center">
		
		<div class="col-md-12 py-2">
			<div class="card">			

				<div class="card-header" >				
					<?php if (isset($component)) { $__componentOriginalc374d1135236aadbf5b5753ac8c94247 = $component; } ?>
<?php $component = App\View\Components\Btnmore::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btnmore'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Btnmore::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc374d1135236aadbf5b5753ac8c94247)): ?>
<?php $component = $__componentOriginalc374d1135236aadbf5b5753ac8c94247; ?>
<?php unset($__componentOriginalc374d1135236aadbf5b5753ac8c94247); ?>
<?php endif; ?>					
				</div>
				
				<div class="card-body">
						<?php echo $__env->make('livewire.pages.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<div class="table-responsive">
					<table class="table able-borderless shadow-sm">
						<thead class="table-dark rounded">
							<tr> 
								<td>#</td> 
								<th>User</th>
								<th>Name</th>
								<th>Url</th>
								<th class="text-center thead">Active</th>
								<th class="text-center thead">Command</th>
							</tr>
						</thead>
						<tbody>
							<?php $__empty_1 = true; $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<tr>
								<td><?php echo e($loop->iteration); ?></td> 
								<td class="text-wrap text-break"><?php echo e($row->user->name); ?></td>
								<td class="text-wrap text-break"><?php echo e($row->name); ?></td>
								<td class="text-wrap text-break"><?php echo e($row->url); ?></td>

								<td class="text-center p-3">
								
									<?php if (isset($component)) { $__componentOriginal13b5cfa2eca6e6af6cba4928f4de2117 = $component; } ?>
<?php $component = App\View\Components\ComActive::resolve(['active' => $row->active] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('com-active'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ComActive::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal13b5cfa2eca6e6af6cba4928f4de2117)): ?>
<?php $component = $__componentOriginal13b5cfa2eca6e6af6cba4928f4de2117; ?>
<?php unset($__componentOriginal13b5cfa2eca6e6af6cba4928f4de2117); ?>
<?php endif; ?>

								</td>
								
								<td width="90">
										<?php if (isset($component)) { $__componentOriginal2680a9b127cdd78a72733543535b391b = $component; } ?>
<?php $component = App\View\Components\Btncrud::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btncrud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Btncrud::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> 
											 <?php $__env->slot('id_editar', null, []); ?> <?php echo e($row->id); ?> <?php $__env->endSlot(); ?>
										 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2680a9b127cdd78a72733543535b391b)): ?>
<?php $component = $__componentOriginal2680a9b127cdd78a72733543535b391b; ?>
<?php unset($__componentOriginal2680a9b127cdd78a72733543535b391b); ?>
<?php endif; ?>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<tr>
								<td class="text-center" colspan="100%">No data Found </td>
							</tr>
							<?php endif; ?>
						</tbody>
					</table>						
					<div class="float-end"><?php echo e($pages->links()); ?></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div><?php /**PATH C:\Users\USER\Desktop\BASE\Botchatur\Admin\resources\views/livewire/pages/view.blade.php ENDPATH**/ ?>