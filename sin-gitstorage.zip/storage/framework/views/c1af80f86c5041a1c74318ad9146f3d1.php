<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>
        <?php if (! empty(trim($__env->yieldContent('title')))): ?>
            <?php echo $__env->yieldContent('title'); ?> |
        <?php endif; ?> <?php echo e(config('app.name', 'Laravel')); ?>

    </title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body>

    <div id="app">

        <nav class="navbar navbar-expand-md  shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'Laravel')); ?>

                </a>
                <button class="navbar-toggler bg-primary" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon bg-primary"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <?php if(auth()->guard()->check()): ?>
                        <ul class="navbar-nav mr-auto">
                            <!--Nav Bar Hooks - Do not delete!!-->
                            <li class="nav-item">

                                <a href="<?php echo e(url('/admin/pages')); ?>" class="nav-link">🟣 <?php echo e(__('messages.pages')); ?></a>

                            </li>
                        </ul>
                    <?php endif; ?>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto">
                        <!-- Authentication Links -->
                        <?php if (isset($component)) { $__componentOriginalacd8d9843a84f65e4186efacf8caa154 = $component; } ?>
<?php $component = App\View\Components\ComLengue::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ComLengue'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ComLengue::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalacd8d9843a84f65e4186efacf8caa154)): ?>
<?php $component = $__componentOriginalacd8d9843a84f65e4186efacf8caa154; ?>
<?php unset($__componentOriginalacd8d9843a84f65e4186efacf8caa154); ?>
<?php endif; ?>
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                                    data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    👻 <span class="text-capitalize"><?php echo e(Auth::user()->name); ?></span>
                                </a>


                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                        onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        
        <?php if (isset($component)) { $__componentOriginal7eddbbad14b5160e6ae3e9b622b29df2 = $component; } ?>
<?php $component = App\View\Components\Comnav1::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('comnav1'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Comnav1::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7eddbbad14b5160e6ae3e9b622b29df2)): ?>
<?php $component = $__componentOriginal7eddbbad14b5160e6ae3e9b622b29df2; ?>
<?php unset($__componentOriginal7eddbbad14b5160e6ae3e9b622b29df2); ?>
<?php endif; ?> 
        <main class="py-1">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('sider-bar-app', [])->html();
} elseif ($_instance->childHasBeenRendered('NyEqs6l')) {
    $componentId = $_instance->getRenderedChildComponentId('NyEqs6l');
    $componentTag = $_instance->getRenderedChildComponentTagName('NyEqs6l');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('NyEqs6l');
} else {
    $response = \Livewire\Livewire::mount('sider-bar-app', []);
    $html = $response->html();
    $_instance->logRenderedChild('NyEqs6l', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('sidebar-wire', [])->html();
} elseif ($_instance->childHasBeenRendered('bWAPVm5')) {
    $componentId = $_instance->getRenderedChildComponentId('bWAPVm5');
    $componentTag = $_instance->getRenderedChildComponentTagName('bWAPVm5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('bWAPVm5');
} else {
    $response = \Livewire\Livewire::mount('sidebar-wire', []);
    $html = $response->html();
    $_instance->logRenderedChild('bWAPVm5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 
            
        </main>

    </div>

    <?php if (isset($component)) { $__componentOriginal08c881877847a3d2b434f66c4c3f3eb4 = $component; } ?>
<?php $component = App\View\Components\ComFooterApp::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('com-footer-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ComFooterApp::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal08c881877847a3d2b434f66c4c3f3eb4)): ?>
<?php $component = $__componentOriginal08c881877847a3d2b434f66c4c3f3eb4; ?>
<?php unset($__componentOriginal08c881877847a3d2b434f66c4c3f3eb4); ?>
<?php endif; ?>

    <?php echo \Livewire\Livewire::scripts(); ?>


    <script>


    </script>


    <script type="module">
        if (window.location.href.indexOf('/admin/') !== -1) {
            const addModal = new bootstrap.Modal('#createDataModal');
            const editModal = new bootstrap.Modal('#updateDataModal');
            window.addEventListener('closeModal', () => {
               addModal.hide();
               editModal.hide();
            })
        }
    </script>
    <script>
        function turnOnDarkMode() {
            document.querySelector('body').classList.add('dark');
            document.querySelectorAll('.bg-white').forEach(el => {
                //el.classList.remove('bg-white');
                el.classList.add('bg-dark');
            });
        }

        function turnOffDarkMode() {
            document.querySelector('body').classList.remove('dark');
            document.querySelectorAll('.bg-dark').forEach(el => {
                el.classList.remove('bg-dark');
                //el.classList.add('bg-white');
            });
        }
    </script>
    <script src="/js/alpinejs.js" defer></script>
</body>

</html>
<?php /**PATH C:\Users\USER\Desktop\BASE\Botchatur\Admin\resources\views/layouts/app.blade.php ENDPATH**/ ?>