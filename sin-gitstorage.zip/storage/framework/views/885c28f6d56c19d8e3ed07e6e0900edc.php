<div>
    <a wire:click.prevent="switchLanguage('es')" href="#">Es</a> / 
    <a wire:click.prevent="switchLanguage('en')" href="#">En</a>

    paginato : 
    <a href="<?php echo e(url('/admin/pages')); ?>" class="nav-link"><?php echo e(__('messages.pages')); ?></a>
    <p>Current language: <?php echo e(App::getLocale()); ?></p>
    </div>
<?php /**PATH C:\Users\USER\Desktop\BASE\Botchatur\Admin\resources\views/livewire/language-switcher.blade.php ENDPATH**/ ?>