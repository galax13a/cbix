<?php return array (
  'com-dark-wire' => 'App\\Http\\Livewire\\ComDarkWire',
  'language-switcher' => 'App\\Http\\Livewire\\LanguageSwitcher',
  'pages' => 'App\\Http\\Livewire\\Pages',
  'sidebar-wire' => 'App\\Http\\Livewire\\SidebarWire',
  'sider-bar-app' => 'App\\Http\\Livewire\\SiderBarApp',
);