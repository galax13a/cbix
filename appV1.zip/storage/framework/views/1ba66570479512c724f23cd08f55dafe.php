<div>
  
    <div class="navbar-brand mb-0 h1">
        <div class="btn-group dropstart">
            <button class="btn dropdown-toggle dropdown-menu-start show" id="languageDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                <?php if(App::getLocale() === 'es'): ?>
                    <img src="/icons/es.png" alt="Spanish" class="language-icon"> Spa
                <?php elseif(App::getLocale() === 'en'): ?>
                    <img src="/icons/en.png" alt="English" class="language-icon"> En.
                <?php endif; ?>
            </button>
            <ul class="dropdown-menu dropdown-menu-end dropdown-menu-lg-start" aria-labelledby="languageDropdown">
                <li>
                    <a class="dropdown-item text-decoration-none" href="<?php echo e(url('/es')); ?>">
                        <img src="/icons/es.png" alt="Spanish" class="language-icon"> Spanish
                    </a>
                </li>
                <li>
                    <a class="dropdown-item text-decoration-none" href="<?php echo e(url('/en')); ?>">
                        <img src="/icons/en.png" alt="English" class="language-icon"> English
                    </a>
                </li>
            </ul>
        </div>
    </div>
    
</div><?php /**PATH C:\Users\USER\Desktop\BASE\Botchatur\Admin\resources\views/components/com-lengue.blade.php ENDPATH**/ ?>