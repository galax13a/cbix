<?php $__env->startSection('title', __('Test Speed Webcam')); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card my-4">

                    <div class="card-body ">

                        <h1>Test Speed</h1>

                        <div class="ratio ratio-21x9">
                          <iframe src="https://fast.com/en" title="Test Speed allowfullscreen"></iframe>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\BASE\Botchatur\Admin\resources\views/testspeed.blade.php ENDPATH**/ ?>