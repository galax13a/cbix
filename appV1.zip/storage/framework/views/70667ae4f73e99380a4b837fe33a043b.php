<div>
    <label class="toggle">
        <input wire:model="active" id="active" class="toggle-checkbox" type="checkbox" <?php echo e($active ? 'checked' : ''); ?>>
        <div class="toggle-switch"></div>
        <span class="toggle-label"><?php echo e($active ? 'Active' : 'Inactive'); ?></span>
    </label>
        
</div><?php /**PATH C:\Users\USER\Desktop\BASE\Botchatur\Admin\resources\views/components/com-check.blade.php ENDPATH**/ ?>