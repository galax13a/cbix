<div>
    <!-- It is never too late to be what you might have been. - George Eliot -->
    <!-- As a heading -->
    <nav class="navbar">
        <div class="container-fluid">
            <a href="#memberplus" class="navbar-brand mb-0 h1">🏅 Member Plus</a>
            <a href="#appbot" class="navbar-brand mb-0 h2">🐞 app bot</a>
            <a href="#appchat" class="navbar-brand mb-0 h3">🗨️ app chat</a>
            <a href="#videochat" class="navbar-brand mb-0 h3">👅 video chat</a>
            <a href="#videos" class="navbar-brand mb-0 h3">🫦 videos </a>
            <!--  dark mode -->
            <a href="#videos" class="navbar-brand mb-0 h3"> <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('com-dark-wire', [])->html();
} elseif ($_instance->childHasBeenRendered('qanlQA4')) {
    $componentId = $_instance->getRenderedChildComponentId('qanlQA4');
    $componentTag = $_instance->getRenderedChildComponentTagName('qanlQA4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qanlQA4');
} else {
    $response = \Livewire\Livewire::mount('com-dark-wire', []);
    $html = $response->html();
    $_instance->logRenderedChild('qanlQA4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> </a>                       
            <!-- ... -->
        </div>

</div>
</nav>

</div>
<?php /**PATH C:\Users\USER\Desktop\BASE\Botchatur\Admin\resources\views/components/comnav1.blade.php ENDPATH**/ ?>