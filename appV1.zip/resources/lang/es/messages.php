<?php

return [
    'welcome' => 'Bienvenido',
    'login' => 'Iniciar sesión',
    'pages' => 'paginas',
    'language' => 'Spanish',
    // etc...
];
