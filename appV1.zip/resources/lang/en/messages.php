<?php

return [
    'welcome' => 'Home Wolcome',
    'login' => 'Login',
    'register' => 'Register',
    'pages' => 'Hosts Pages',
    'language' => 'English',
    // etc...
];
